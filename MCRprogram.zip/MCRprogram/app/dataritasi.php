<?php
require '../vendor/autoload.php';
require '../config/koneksi.php';
if(isset ($_POST['submit'])){
  $err        = "";
  $ekstensi   = "";
  $success    = "";

  $file_name = $_FILES['filexls']['name'];
  $file_data = $_FILES['filexls']['tmp_name'];

  if(empty($file_name)){
    $err .= "<li> Silahkan Masukan File.</li>";

  }else{
    $ekstensi = pathinfo($file_name)['extension'];

  }
  $ekstensi_allowed = array ("xls","xlsx");
  if (!in_array($ekstensi,$ekstensi_allowed)){
    $err .= "<li> Silahkan Masukan File tipe xls, atau xlsx. <b>$file_name</b> punya tipe <b>$ekstensi</b></li>";
  }
  if(empty($err)){
    $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile($file_data);
    $spreadsheet = $reader->load($file_data);
    $sheetData = $spreadsheet->getActiveSheet()->toArray();

    $jumlahData = 0;
    for($i=1;$i<count($sheetData);$i++){
      $date= $sheetData[$i]['0'];
      $nama = $sheetData[$i]['1'];
      $versatility = $sheetData[$i]['2'];
      $site = $sheetData[$i]['3'];

      $sql1 = "insert into ritase (date, shift, nik_op, nama_op) values ('$nik','$nama','$versatility','$site')";
      
      mysqli_query  ($koneksi,$sql1);
      $jumlahData++;
      

    }

    if($jumlahData > 0 ){
      $success = "Data Berhasil di Import";   
    
      }
      
  } 
  
  if($err){
    ?>
    <div class ="alert alert-danger">
      <ul><?php echo $err ?></ul>
  </div>
  <?php

  }
  if ($success){
    ?>
    <div class="alert alert-primary">
      <?php echo $success ?>
      
  </div>
  
  <?php
  
  }
}

?>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-13">
            
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Data Ritase</h3>
              </div>
              <!-- /.card-header -->
              
              <div class="card-body">
              <div class = "form-group">
              <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-lg">
                  Tambah Data
                </button>
                </div>
                <div class="card-body">
                <div class ="form-group">
            
              <div class="btn-group w-20">
             <form action="" method="POST" enctype="multipart/form-data" >
              <input class="btn btn-primary col fileinput-button "type="file" name="filexls">
            </div>
              <input class="btn btn-success" type="submit" name="submit" value="Upload Excel">


              </form>
</div>

                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Date</th>
                    <th>Shift</th>
                    <th>Time</th>
                    <th>NIK</th>
                    <th>Op.Loader</th>
                    <th>NIK</th>
                    <th>Op.Hauler</th>
                    <th>Loader</th>
                    <th>Model</th>
                    <th>Hauler</th>
                    <th>Model</th>
                    <th>Block</th>
                    <th>Pit</th>
                    <th>Distance</th>
                    <th>Ritase</th>
                    <th>Material</th>
                    <th>Submaterial</th>
                    <th>Produksi </th>
                    <th>Adjustment</th>
                    <th>Dist*Vol</th>
                    <th>Productivity Factor</th>
                    <th>Detail Productivity</th>
                    <th>Dumping</th>
                    <th>Created By</th>
                     
         
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                    $no = 0;
                    $query = mysqli_query($koneksi, "SELECT * FROM ritase");
                    while ($ritasi= mysqli_fetch_array($query)){
                      $no++
                    ?>
                  <tr>
                    
                    <td width='5%'><?php echo $ritasi['id'];?></td>
                    <td><?php echo $ritasi['date'];?></td>
                    <td><?php echo $ritasi['shift'];?></td>
                    <td><?php echo $ritasi['time'];?></td> 
                    <td><?php echo $ritasi['nik_loader'];?></td>
                    <td><?php echo $ritasi['nama_loader'];?></td>
                    <td><?php echo $ritasi['nik_hauler'];?></td>
                    <td><?php echo $ritasi['nama_hauler'];?></td>
                    <td><?php echo $ritasi['code_loader'];?></td>
                    <td><?php echo $ritasi['model_loader'];?></td>
                    <td><?php echo $ritasi['code_hauler'];?></td>
                    <td><?php echo $ritasi['model_hauler'];?></td>
                    <td><?php echo $ritasi['block'];?></td>
                    <td><?php echo $ritasi['pit'];?></td>
                    <td><?php echo $ritasi['distance'];?></td>
                    <td><?php echo $ritasi['ritase'];?></td>
                    <td><?php echo $ritasi['material'];?></td>
                    <td><?php echo $ritasi['sub_material'];?></td>
                    <td><?php echo $ritasi['produksi'];?></td>
                    <td><?php echo $ritasi['adjustment'];?></td>
                    <td><?php echo $ritasi['dist_vol'];?></td>
                    <td><?php echo $ritasi['factor'];?></td>
                    <td><?php echo $ritasi['detail'];?></td>
                    <td><?php echo $ritasi['dumping'];?></td>
                    <td><?php echo $ritasi['createdby'];?></ttd>

                    
                  </tr>
                  <?php }?>

                  </tbody>
                 
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
      </section>
   
      <div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Data Ritase</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <diV class ="container">
            <form method="POST" action="add/tambah_ritasi.php">
            
            <tabel class="table table-bordered table-striped">
           
              
            <div class="col-xs-4 col-md-4">
              <label>Date</label>
              <input class="form-control" type="date"  aria-label=".form-control-sm example" name='date' required>
              </div>
              <div>  
              <div class="col-xs-4 col-md-4">
                        <label>Shift</label>  
                        <select class="form-control" name='shift'>
                        <option value="">-- Shift --</option>
                        <?php
                
                            $shift = mysqli_query($koneksi, "SELECT * FROM tbl_time");
                            while ($s= mysqli_fetch_array($shift)){
                          
                            ?>
                        <option value="<?php echo $s['shift']; ?>"><?php echo $s['shift']; ?></option>

                        <?php }?>
                    </select>
                    </div>
                    
                    <div>
                        <div class="col-xs-4 col-md-4">
                        <label>Time</label>
                        <select class="form-control" name='time' >
                        <option value="">-- Time --</option>
                        <?php
                
                          $time = mysqli_query($koneksi, "SELECT * FROM tbl_time");
                          while ($t= mysqli_fetch_array($time)){
                        
                          ?>
                      <option value="<?php echo $t['time']; ?>"><?php echo $t['time']; ?></option>

                      <?php }?>
                    </select>
                    </div>
                  
                    </div>
                    
              <div class = "form-row">
              <!-- <div class="col">
                <input type="text" class="form-control" placeholder="ID" name ="id" required>
              </div> -->
              <div class="col-sm-4">
                <label>Site</label>
               <select class="form-control" name='site' required>
              <option  value="">-- Site --</option>
              <?php
                
                    $site = mysqli_query($koneksi, "SELECT * FROM ms_site");
                    while ($s= mysqli_fetch_array($site)){
                  
                    ?>
                <option value="<?php echo $s['site']; ?>"><?php echo $s['site']; ?></option>

                <?php }?>
              </select>
              </div>
                      
            
                      
              <div class="col-sm-4">
              <label>Operator Loader</label>
              <select name="nama_loader" id="nama-loader" class="form-control nama"  required >
              <option value="">-- Pilih Nama --</option>
              <?php
                
                $nik = mysqli_query($koneksi, "SELECT * FROM operator");
                while ($n= mysqli_fetch_array($nik)){
              
                ?>
            <option value="<?php echo $n['nama']; ?>"><?php echo $n['nama']; ?></option>

            <?php }?>
                     </select>
              </div>
              <div class="col-sm-4">
              <label>NIK Loader</label>
              <input  name="nik_loader" id="nik-loader" class="form-control nik" placeholder = "NIK Loader" readonly>
             
              <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
              <script>
                      $(function() {
                        $("#nama-loader").change(function(){
                          var nama_loader = $("#nama-loader").val();

                          $.ajax({
                            url: 'proses/proses_opL.php',
                            type: 'POST',
                            dataType: 'json',
                            data: {
                              'nama': nama_loader
                            },
                          success: function(operator) {
                          console.log(operator);
                          $('#nik-loader').val(operator.nik);
                          
                            }
                          });
                        });

                      
                      });
                    </script>
                     </input>
              </div>
              
              
              <div class="col-sm-4">
              <label>Operator Hauler</label>
              <select name="nama_hauler" id="nama-hauler" class="form-control nama"  required >
              <option value="">-- Pilih Operator --</option>
              <?php
                
                $nik = mysqli_query($koneksi, "SELECT * FROM operator");
                while ($n= mysqli_fetch_array($nik)){
              
                ?>
            <option value="<?php echo $n['nama']; ?>"><?php echo $n['nama']; ?></option>

            <?php }?>
                     </select>
              </div>
              <div class="col-sm-4">
              <label>NIK Hauler</label>
              <input  class = "form-control nik" id="nik-hauler" name="nik_hauler" placeholder="NIK Hauler" readonly>    
              
              <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
                    <script>
                      $(function() {
                        $("#nama-hauler").change(function(){
                          var nama_hauler = $("#nama-hauler").val();

                          $.ajax({
                            url: 'proses/proses_opH.php',
                            type: 'POST',
                            dataType: 'json',
                            data: {
                              'nama': nama_hauler
                            },
                          success: function(operator) {
                          console.log(operator);
                          $('#nik-hauler').val(operator.nik);
                        
                            
                            

                              
                              
                            }
                          });
                        });

                      
                      });
                    </script>
                    
                </input>
              </div>
                        
              <div class="col-sm-4">
              <label>Loader</label>
              <select class = "form-control unit_loader"  name="code_loader"  id="unit-loader"  required>  
              <option value="">-- Loader --</option>
              <?php
                
                $unit = mysqli_query($koneksi, "SELECT * FROM ms_equipment");
                while ($u= mysqli_fetch_array($unit)){
              
                ?>
            <option value="<?php echo $u['unit_loader']; ?>"><?php echo $u['unit_loader']; ?></option>

            <?php }?>
              </select>
              </div>
              <div class="col-sm-4">
              <label>Model Loader</label>
              <input class="form-control model_loader" placeholder ="Model Loader" name="model_loader" id="model_loader" readonly>
             
              <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
                    <script>
                      $(function() {
                        $("#unit-loader").change(function(){
                          var loader = $("#unit-loader").val();

                          $.ajax({
                            url: 'proses/proses_loader.php',
                            type: 'POST',
                            dataType: 'json',
                            data: {
                              'unit_loader': loader
                            },
                          success: function(ms_equipment) {
                          console.log(ms_equipment);
                          $('#model_loader').val(ms_equipment.model_loader);
                        
                            
                            

                              
                              
                            }
                          });
                        });

                      
                      });
                    </script>
                    
                    </input>  
              </div>
              <div class="col-sm-4">
              <label>Hauler</label>
             <select name="code_hauler" id="unit-hauler" class="form-control unit_hauler" required >
              <option value="">-- Hauler --</option>
              <?php
                
                $unit = mysqli_query($koneksi, "SELECT * FROM ms_equipment");
                while ($u= mysqli_fetch_array($unit)){
              
                ?>
            <option value="<?php echo $u['unit_hauler']; ?>"><?php echo $u['unit_hauler']; ?></option>

            <?php }?>
              </select>
              </div>

              <div class="col-sm-4">
              <label>Model Hauler</label>
              <input type="text" class="form-control model_hauler" placeholder= "Model Hauler" name ="model_hauler" id = "model_hauler" readonly>
              
                </input>
              </div>

              <div class="col-sm-4">
              <label>Truck Factor</label>
                <input  type="text" class="form-control" placeholder="Truck Factor" name ="truck_factor" id="ob" readonly>
                
                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
                    <script>
                      $(function() {
                        $("#unit-hauler").change(function(){
                          var hauler = $("#unit-hauler").val();

                          $.ajax({
                            url: 'proses/proses_hauler.php',
                            type: 'POST',
                            dataType: 'json',
                            data: {
                              'unit_hauler': hauler
                            },
                            
                            success: function (ms_equipment) {
                              console.log(ms_equipment);
                              $("#model_hauler").val(ms_equipment.model_hauler);
                              $("#ob").val(ms_equipment.ob);

                              
                              
                            }
                          });
                        });

                     
                      });
                    </script>
                </input>
              </div>

                 
              <div class="col-sm-4">
              <label>Block</label>
              <select class="form-control" name='block' id="blok" required>
              <option value="">-- Block --</option>
              <?php
                
                $blok = mysqli_query($koneksi, "SELECT * FROM ms_location");
                while ($b= mysqli_fetch_array($blok)){
              
                ?>
            <option value="<?php echo $b['blok']; ?>"><?php echo $b['blok']; ?></option>

            <?php }?>
              </select>
              </div>
                    
              
              <div class="col-sm-4">
              <label>Pit</label>
              <select type="text" class="form-control" placeholder="Pit" name ="pit" id="pit" readonly>
              <option value="">-- Pit --</option>
              <?php
                
                $pit = mysqli_query($koneksi, "SELECT * FROM ms_location");
                while ($p= mysqli_fetch_array($pit)){
              
                ?>
            <option value="<?php echo $p['pit']; ?>"><?php echo $p['pit']; ?></option>

            <?php }?>
                </select>
              </div>
             
             

              <div class="col-sm-4">
              <label>Submaterial</label>
              <select class="form-control" name='sub_material' id="sub_material" required>
              <option value="">-- Sub Material --</option>
              <?php
                
                $sub = mysqli_query($koneksi, "SELECT * FROM tbl_material");
                while ($s= mysqli_fetch_array($sub)){
              
                ?>
            <option value="<?php echo $s['sub_material']; ?>"><?php echo $s['sub_material']; ?></option>

            <?php }?>
              </select>
              </div> 
              <div class="col-sm-4">
               <label>Material</label> 
              <input type="text" class="form-control" placeholder="Material" name ="material" id ="material" readonly>
           
                </input>
              </div> 
              <div class="col-sm-4">
              <label>Material Factor</label>
              <input class="form-control" name='material_factor' id="factor"  readonly>
              <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
                    <script>
                      $(function() {
                        $("#sub_material").change(function(){
                          var sub_material = $("#sub_material").val();

                          $.ajax({
                            url: 'proses/proses_material.php',
                            type: 'POST',
                            dataType: 'json',
                            data: {
                              'sub_material': sub_material
                            },
                            success: function (tbl_material) {
                              $("#material").val(tbl_material['material']);
                              $("#factor").val(tbl_material['factor']);

                              
                              
                            }
                          });
                        });

                     
                      });
                    </script>
              
                    </input>
              </div>
              <div class="col-sm-4">
              <label>Ritase</label>
                <input type="text"  class="form-control" id="ritase"  name="ritase" >    
            </input>     
              </div>
              <div class="col-sm-4">
              <label>Distance</label>
                <input type="text" class="form-control" placeholder="Distance" name ="distance" id="distance">
            </input>
              </div>
      
              <div class="col-sm-4">
              <label>Produksi </label>
                <input type="text" class ="form-control"id="total_produksi" name="produksi"   readonly>
                
            </input>
           
              </div>
              
              <div class="col-sm-4">
              <label>Produksi (Adjustment) </label>
                <input type="text" class ="form-control"id="total_adjust"  name="adjustment" readonly>
                
              </input>
              </div>
              <div class="col-sm-4">
              <label>Dist*Vol</label>
                <input type="text" class ="form-control"id="dist_vol"  name="dist_vol" readonly>
                
              </input>
              </div>
              <div class="col-sm-4">
              <label>Produksi Factor</label>
              <select class="form-control" name='factor' required>
              <option  value="">-- Produksi Factor --</option>
              <?php
                
                $factor = mysqli_query($koneksi, "SELECT * FROM ms_sitefactor");
                while ($f= mysqli_fetch_array($factor)){
              
                ?>
            <option value="<?php echo $f['factor']; ?>"><?php echo $f['factor']; ?></option>

            <?php }?>
              
              </select>
              </div>
              <div class="col-sm-4">
              <label>Detail Productivity Problem</label>
              <select class="form-control" name='detail' required>
              <option value="">-- Detail Productivity Problem --</option>
              <?php
                
                $detail = mysqli_query($koneksi, "SELECT * FROM ms_sitefactor");
                while ($d= mysqli_fetch_array($detail)){
              
                ?>
            <option value="<?php echo $d['detail_factor']; ?>"><?php echo $d['detail_factor']; ?></option>

            <?php }?>
              
              </select>
              </div>
             
              <div class="col-sm-4">
              <label>Dumping</label>
              <input class="form-control" name='dumping' required>
              
                </input>
              </div>
             
              <div class="col-sm-4">
              <label>Remark</label>
                <input type="text" class="form-control" placeholder="Remark" name ="remark">
              </div>
         
                    </div>
                    </tabel>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
              <button type="submit"  class="btn btn-primary">Kirim</button>
            </div>
          </div>
          </form>
          <form>
            <script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
            <script type="text/javascript">
                $(document).ready(function() {
                    $("#ob, #ritase").keyup(function() {
                        var truck  = $("#ob").val();
                        var ritase = $("#ritase").val();

                        var total_produksi = truck * ritase;
                        $("#total_produksi").val(total_produksi);
                    });
                });
            </script>
            </form>
            <form>
            
            <script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
            <script type="text/javascript">
                $(document).ready(function() {
                    $("#ob, #ritase, #factor").keyup(function() {
                        var truck  = $("#ob").val();
                        var ritase = $("#ritase").val();
                        var material = $("#factor").val();

                        var total_adjust = truck * ritase * material;
                        $("#total_adjust").val(total_adjust);
                    });
                });
            </script>
            </form>
          
            <form>
            <script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
            <script type="text/javascript">
                $(document).ready(function() {
                    $("#total_adjust, #distance").keyup(function() {
                        var adjustment  = $("#total_adjust").val();
                        var distance = $("#distance").val();

                        var dist_vol = distance/1000 * adjustment;
                        $("#dist_vol").val((dist_vol).toFixed(2));
                    });
                });
            </script>
            </form>
           