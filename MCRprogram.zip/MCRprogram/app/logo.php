<a href="index.php" class="brand-link">
      <img src="dist/img/manggala.png" alt="Manggala" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light justify-content-center align-items-center">MCR Program</span>
    </a>
