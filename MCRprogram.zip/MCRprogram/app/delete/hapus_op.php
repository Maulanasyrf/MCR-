<?php
include('../../config/koneksi.php');
$nik= $_GET['nik'];

$query = mysqli_query($koneksi,"DELETE FROM ms_operator WHERE nik='$nik'");
header ('Location:../index.php?page=master-operator');
?>  