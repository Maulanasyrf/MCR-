<?php
include('../../config/koneksi.php');
$code= $_GET['code'];

$query = mysqli_query($koneksi,"DELETE FROM ms_customer WHERE code='$code'");
header ('Location:../index.php?page=master-customer');
?>  