
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-13">
            
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Hourly Monitoring Performance</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
              
                </button>
                <br></br>
                <table id="example1" class="table table-bordered ">
                  <thead>
                  <tr>
                  
                    <th rowspan="2">Date</th>
                    <th rowspan="2" style="width:100%" align="center">Code Unit</th>
                    <th align="center" colspan="12"> Shift 1</th>
                     
                      <th rowspan="2" style="width:100%" >Total Shift 1</th>
                    
                    <th colspan="12">Shift 2</th>
                   
                    <th rowspan="2" style="width:100%">Total Shift 2</th>
                  </tr>
                  <tr>
                  
                      <td>06.00-07.00</td>
                      <td>07.00-08.00</td>
                      <td>08.00-09.00</td>
                      <td>09.00-10.00</td>
                      <td>10.00-11.00</td>
                      <td>11.00-12.00</td>
                      <td>12.00-13.00</td>
                      <td>13.00-14.00</td>
                      <td>14.00-15.00</td>
                      <td>15.00-16.00</td>
                      <td>16.00-17.00</td>
                      <td>17.00-18.00</td>
                     
                      <td>18.00-19.00</td>
                      <td>19.00-20.00</td>
                      <td>20.00-21.00</td>
                      <td>21.00-22.00</td>
                      <td>22.00-23.00</td>
                      <td>23.00-24.00</td>
                      <td>24.00-01.00</td>
                      <td>01.00-02.00</td>
                      <td>02.00-03.00</td>
                      <td>03.00-04.00</td>
                      <td>04.00-05.00</td>
                      <td>05.00-06.00</td>
</tr>

                  </thead>
                  <tbody>
                  <tbody>
                    <?php
                    $no = 0;
                    $query = mysqli_query($koneksi, "SELECT * FROM ritase");
                    while ($ritasi= mysqli_fetch_array($query)){
                      $no++
                    ?>
                  <tr>
                    
                   
                  
                
                 
                  
                    
                    <td><?php echo $ritasi['date'];?></td>
                  
                    <td><?php echo $ritasi['code_loader'];?></td>
                
                    
                   
                   

                    
                  </tr>
                  <?php }?>

                  </tbody>
                 
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
      </section>
      <div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Master Customer</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <form method="get" action="add/tambah_data.php">
            <div class="modal-body">
            <div class="form-row">
              <div class="col">
                <input type="text" class="form-control" placeholder="Code" name ="code" required>
              </div>
              <div class="col">
                <input type="text" class="form-control" placeholder="Description" name ="description" required>
              </div>
              <div class="col">
                <input type="text" class="form-control" placeholder="Address" name ="address" required>
              </div>
              <div class="col">
                <input type="text" class="form-control" placeholder="Telp" name ="telp">
              </div>
            </div>
          
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Save</button>
            </div>
          </div>
          </form>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <script>
        function hapus_data(data_customer){
          // alert('ok');
          // window.location=("delete/hapus_data.php?code="+data_customer);
          Swal.fire({
              title: 'Apakah anda yakin ingin menghapus data?',
              // showDenyButton: false,
              showCancelButton: true,
              confirmButtonText: 'Hapus Data',
              confirmButtonColor:'red'
              // denyButtonText: `Don't save`,
            }).then((result) => {
              /* Read more about isConfirmed, isDenied below */
              if (result.isConfirmed) {
                window.location=("delete/hapus_data.php?code="+data_customer);
              } 
            })
        }
      </script>