
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Master Site Location</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
              <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-lg">
                  Tambah
              </button>
                <br></br>
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                  <!-- <th>Shift</th>
                  <th>Start</th>
                  <th>End</th> -->
                    <th>Location</th>
                    <th>Type</th>
                    <th>Block</th>
                    <th>Pit</th>
                    <th>Dumping</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                
                    $query = mysqli_query($koneksi, "SELECT * FROM ms_location");
                    while ($location= mysqli_fetch_array($query)){
                
                    ?>
                  <tr>
                  
                    <td width='5%'><?php echo $location['location'];?></td>
                    <td><?php echo $location['type'];?></td>
                    <td><?php echo $location['blok'];?></td>
                    <td><?php echo $location['pit'];?></td>
                    <td><?php echo $location['dumping'];?></td>
                    <td><a onclick="hapus_op(<?php echo $location['location'];?>)" class="btn btn-sm btn-danger">Hapus</a>
                        <a href="index.php?page=edit-data&& location=<?php echo $location['location'];?>" class="btn btn-sm btn-success">Edit</a>
                  </td>
                  </tr>
                  <?php }?>

                  </tbody>
                  
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
      </section>
      <div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Master Site Location</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <form method="get" action="add/tambah_op.php">
            <div class="modal-body">
            <div class="form-row">
            
            <div class="col">
                <input type="text" class="form-control" placeholder="Code" name ="code" required>
              </div>
              <div class="col">
                <input type="text" class="form-control" placeholder="Nama" name ="nama" required>
              </div>
              <div class="col">
                <input type="text" class="form-control" placeholder="Versatility" name ="versatility" required>
              </div>
              <div class="col">
                <input type="text" class="form-control" placeholder="Sitecode" name ="sitecode">
              </div>
            </div>
          
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss= "modal">Close</button>
              <button type="submit" class="btn btn-primary">Save</button>
            </div>
          </div>
          </form>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <script>
        function hapus_op(data_op){
          // alert('ok');
          // window.location=("delete/hapus_op.php?code="+data_customer);
          Swal.fire({
              title: 'Apakah anda yakin ingin menghapus data?',
              // showDenyButton: false,
              showCancelButton: true,
              confirmButtonText: 'Hapus Data',
              confirmButtonColor:'red'
              // denyButtonText: `Don't save`,
            }).then((result) => {
              /* Read more about isConfirmed, isDenied below */
              if (result.isConfirmed) {
                window.location=("delete/hapus_op.php?code="+data_op);
              } 
            })
        }
      </script>