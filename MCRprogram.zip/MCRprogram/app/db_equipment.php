
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-13">
            
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Equipment</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
              <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-lg">
                  Tambah
                </button>
                <br></br>
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  
                  <tr>
                    <th>No</th>
                    <th>Type</th>
                    <th>Loader</th>
                    <th>Model Loader</th>
                    <th>Type Equip</th>
                    <th>Type</th>
                    <th>Hauler</th>
                    <th>Model Hauler</th>
                    <th>Type Equip</th>
                    <th>Category</th>
                    <th>Dedicated</th>
                    <th>Status</th>
                    <th>Toggle</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                    $no = 0;
                    $query = mysqli_query($koneksi, "SELECT * FROM ms_equipment");
                    while ($equipment= mysqli_fetch_array($query)){
                      $no++
                    ?>
                  <tr>
                    <td width='5%'><?php echo $equipment['no'];?></td>
                    <td><?php echo $equipment['tipe_loader'];?></td>
                    <td><?php echo $equipment['unit_loader'];?></td>
                    <td><?php echo $equipment['model_loader'];?></td>
                    <td><?php echo $equipment['typequip_loader'];?></td>
                    <td><?php echo $equipment['tipe_hauler'];?></td>
                    <td><?php echo $equipment['unit_hauler'];?></td>
                    <td><?php echo $equipment['model_hauler'];?></td>
                    <td><?php echo $equipment['typequip_hauler'];?></td>
                    <td><?php echo $equipment['category'];?></td>
                    <td><?php echo $equipment['dedicated'];?></td>
                    
                    <td> <?php 
                        // Usage of if-else statement to translate the 
                        // tinyint status value into some common terms
                        // 0-Inactive
                        // 1-Active
                        if($equipment['status']=="1") 
                            echo "Aktif";
                        else 
                            echo "No Aktif";
                    ?>                          
                </td>
                <td>
                    <?php 
                    if($equipment['status']=="1") 
  
                        // if a course is active i.e. status is 1 
                        // the toggle button must be able to deactivate 
                        // we echo the hyperlink to the page "deactivate.php"
                        // in order to make it look like a button
                        // we use the appropriate css
                        // red-deactivate
                        // green- activate
                        echo 
                "<a href=tool/deactivate.php?no=".$equipment['no']."class='  btn red'>Non Aktifkan</a>";
                                    else 
                                        echo 
                "<a href=tool/activate.php?no=".$equipment['no']."class='btn green'>Aktifkan</a>";
                    ?>
            </tr>
                  </tr>
                  <?php }?>
                  
                  </tbody>
                 
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
      </section>
      <div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Tambah Equipment</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <form method="get" action="add/tambah_equip.php">
            <div class="modal-body">
            <div class="form-row">
            <div class="col-sm-3">
                <input type="text" class="form-control" placeholder="Loader" name ="tipe_loader" required>
              </div>
              <div class="col-sm-3">
                <input type="text" class="form-control" placeholder="Code Unit Loader" name ="unit_loader" required>
              </div>
              <br></br>
              <div class="col-sm-3">
                <input type="text" class="form-control" placeholder="Model Loader" name ="model_loader" required>
              </div>
              <div class="col-sm-3">
                <input type="text" class="form-control" placeholder="Type Equipment Loader" name ="typequip_loader" required>
              </div>
              <div class="col-sm-3">
                <input type="text" class="form-control" placeholder="Hauler" name ="tipe_hauler" required>
              </div>
              <div class="col-sm-3">
                <input type="text" class="form-control" placeholder="Code Unit Hauler" name ="unit_hauler" required>
              </div>
              <div class="col-sm-3">
                <input type="text" class="form-control" placeholder="Model Hauler" name ="model_hauler">
              </div>
              <div class="col-sm-3">
                <input type="text" class="form-control" placeholder="Type Equipment Hauler" name ="typequip_hauler">
              </div>
              <div class="col-sm-3">
                <input type="text" class="form-control" placeholder="Category" name ="category">
                
              </div>
              <div class="col-sm-3">
                <input type="text" class="form-control" placeholder="Truck" name ="truck" required>
              </div>
              <div class="col-sm-3">
                <input type="text" class="form-control" placeholder="OB" name ="ob" required>
              </div>
              <br></br>
              <div class="col-sm-3">
                <input type="text" class="form-control" placeholder="Coal" name ="coal" required>
              </div>
             
              <div class="col-sm-3">
                <input type="text" class="form-control" placeholder="Dedicated" name ="dedicated">
                
              </div>
            </div>
          
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Save</button>
            </div>
          </div>
          </form>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      
      
              
              <div class="card-body">
               
              </div>
          