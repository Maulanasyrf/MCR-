<?php
include('../../config/koneksi.php');
$tipe_loader = $_GET['tipe_loader'];
$unit_loader = $_GET['unit_loader'];
$model_loader = $_GET['model_loader'];
$typeequipL = $_GET['typequip_loader'];
$tipe_hauler = $_GET['tipe_hauler'];
$unit_hauler = $_GET['unit_hauler'];
$model_hauler = $_GET['model_hauler'];
$typequipH = $_GET['typequip_hauler'];
$truck = $_GET['truck'];
$ob = $_GET['ob'];
$coal = $_GET['coal'];
$category = $_GET['category'];
$dedicated = $_GET['dedicated'];
$query = mysqli_query($koneksi,"INSERT INTO ms_equipment (tipe_loader,unit_loader,model_loader,typequip_loader,tipe_hauler,unit_hauler,model_hauler,typequip_hauler,truck,ob,coal,category,dedicated) VALUES ('$tipe_loader','$unit_loader','$model_loader','$typeequipL','$tipe_hauler','$unit_hauler','$model_hauler','$typequipH','$truck','$ob','$coal','$category','$dedicated')");
header ('Location:../index.php?page=master-equipment');
?>  