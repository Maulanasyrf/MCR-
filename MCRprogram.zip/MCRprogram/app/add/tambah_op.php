<?php
include('../../config/koneksi.php');
$nik = $_GET['nik'];
$nama = $_GET['nama'];
$vers = $_GET['versatility'];
$site = $_GET['sitecode'];
$query = mysqli_query($koneksi,"INSERT INTO operator(nik,nama,versatility,site) VALUES ('$nik','$nama','$vers','$site')");
header ('Location:../index.php?page=master-operator');
?>  