
<?php
include('../../config/koneksi.php');


$date = $_POST['date']; 
$shift = $_POST['shift'];
$time = $_POST['time'];
$site = $_POST['site'];
$nikH = $_POST['nik_hauler'];
$operatorH = $_POST['nama_hauler'];
$nikL = $_POST['nik_loader'];
$operatorL = $_POST['nama_loader'];
$L = $_POST['code_loader'];
$modelL = $_POST['model_loader'];
$H = $_POST['code_hauler'];
$modelH = $_POST['model_hauler'];
$blok = $_POST['block'];
$pit = $_POST['pit'];
$dis = $_POST['distance'];
$rit = $_POST['ritase'];
$mat = $_POST['material'];
$sub = $_POST['sub_material'];
$prod = $_POST['produksi'];
$adj = $_POST['adjustment'];
$dist = $_POST['dist_vol'];
$fac= $_POST['factor'];
$det = $_POST['detail'];
$dump = $_POST['dumping'];
$rem = $_POST['remark'];

$query= mysqli_query($koneksi,"INSERT INTO ritase (id,date,shift,time,site,nik_hauler,nama_hauler,nik_loader,nama_loader,code_loader,model_loader,code_hauler,model_hauler,block,pit,distance,
ritase,material,sub_material,produksi,adjustment,dist_vol,factor,detail,dumping,remark) VALUES ('','$date','$shift','$time','$site','$nikH','$operatorH','$nikL','$operatorL',
'$L','$modelL','$H','$modelH','$blok','$pit','$dis','$rit','$mat','$sub','$prod','$adj','$dist','$fac','$det','$dump','$rem')");

header ('Location:../index.php?page=data-ritasi');
?>


