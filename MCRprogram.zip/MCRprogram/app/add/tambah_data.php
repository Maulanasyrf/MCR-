<?php
include('../../config/koneksi.php');
$desc = $_GET['description'];
$add = $_GET['address'];
$telp = $_GET['telp'];
$query = mysqli_query($koneksi,"INSERT INTO ms_customer (code,description,address,telp) VALUES ('','$desc','$add','$telp')");
header ('Location:../index.php?page=master-customer');
?>  