<?php
include('../../config/koneksi.php');
$date = $_POST['date'];
$shift = $_POST['shift'];
$code =$_POST['code'];
$site= $_POST['site'];
$nama= $_POST['nama'];
$awal = $_POST['awal'];
$akhir = $_POST['akhir'];
$total = $_POST['total'];
$item= $_POST['item'];
$cat = $_POST['categori'];
$ded= $_POST['dedicated'];
$rem= $_POST['remark'];
$mod= $_POST['model'];
$ex = $_POST['ex'];
$hd= $_POST['hd'];
$query = mysqli_query($koneksi,"INSERT INTO status_unit (id,date,shift,code,nama,awal,akhir,total,site,item,categori,dedicated,remark,model,ex,hd)
 VALUES ('','$date','$shift','$code','$nama','$awal','$akhir','$total','$site','$item','$cat','$ded','$rem','$mod','$ex','$hd')");
header ('Location:../index.php?page=status');
?>  