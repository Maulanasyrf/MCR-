<?php
$equipment = $_GET ['no'];
$query = mysqli_query($koneksi,"SELECT * FROM ms_equipment WHERE no='$equipment'");
$view = mysqli_fetch_array($query);
?>
<section class = "content">
    <div class = "container-fluid">


<div class="card card-warning">
              <div class="card-header">
                <h3 class="card-title">Edit Data Equipment</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <form method = 'get' action='update/update_data.php'>
                  <div class="row">
                    <div class="col-sm-3">
                      <!-- text input -->
                      
                      
                        <label>Loader</label>
                        <input type="text" class="form-control" placeholder="Loader" name='loader'value ="<?php echo $view['tipe_loader'];?>">
                        <input type="text" class="form-control" placeholder="No" name='no'value ="<?php echo $view['no'];?>"hidden>
                      </div>
                    
                    <div class="col-sm-3">
                     
                        <label>Unit Code Loader</label>
                        <input type="text" class="form-control" placeholder="Unit Code Loader" name='unit_loader'value ="<?php echo $view['unit_loader'];?>">
                      </div>
                    
                  
                  <div class="col-sm-3">
                     
                        <label>Model Loader</label>
                        <input type="text" class="form-control" placeholder="Model Loader" name='model_loader'value ="<?php echo $view['model_loader'];?>">
                      </div>
                    
                  
                  <div class="col-sm-3">
                      
                        <label>Type Equip Loader</label>
                        <input type="text" class="form-control" placeholder="Type Equip Loader" name='typequip_loader'value ="<?php echo $view['typequip_loader'];?>">
                      </div>
                    </div>
                <div>
                  <div class="row">
                  <div class="col-sm-3">
                     
                        <label>Hauler</label>
                        <input type="text" class="form-control" placeholder="Hauler" name='tipe_hauler'value ="<?php echo $view['tipe_hauler'];?>">
                      </div>
                    
                  
                  <div class="col-sm-3">
                     
                        <label>Unit Code Hauler</label>
                        <input type="text" class="form-control" placeholder="Unit Code Hauler" name='unit_hauler'value ="<?php echo $view['unit_hauler'];?>">
                      </div>
                  
                  
                  <div class="col-sm-3">
                    
                        <label>Model Hauler</label>
                        <input type="text" class="form-control" placeholder="Model Hauler" name='model_hauler'value ="<?php echo $view['model_loader'];?>">
                      </div>

                      <div class="col-sm-3">
                    
                    <label>Type Equip Hauler</label>
                    <input type="text" class="form-control" placeholder="Type Equip Hauler" name='typequip_hauler'value ="<?php echo $view['typequip_hauler'];?>">
                  </div>

                  <div class="col-sm-3">
                     
                        <label>Category</label>
                        <input type="text" class="form-control" placeholder="Category" name='category'value ="<?php echo $view['category'];?>">
                      </div>
                  
                  
                  <div class="col-sm-3">
                    
                        <label>Truck</label>
                        <input type="text" class="form-control" placeholder="Truck" name='truck'value ="<?php echo $view['truck'];?>">
                      </div>

                      <div class="col-sm-3">
                    
                    <label>OB</label>
                    <input type="text" class="form-control" placeholder="OB" name='ob'value ="<?php echo $view['ob'];?>">
                  </div>
                  <div class="col-sm-3">
                     
                     <label>Coal</label>
                     <input type="text" class="form-control" placeholder="Coal" name='coal'value ="<?php echo $view['coal'];?>">
                   </div>
               
               
               <div class="col-sm-3">
                 
                     <label>Dedicated</label>
                     <input type="text" class="form-control" placeholder="Dedicated" name='dedicated'value ="<?php echo $view['dedicated'];?>">
                   </div>

                  
</div>
                    

                <br></br>
                  <button class="btn-btn-sm btn-info">Simpan</button>
                  <!-- input states -->
                  <!-- <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Input with
                      success</label>
                    <input type="text" class="form-control is-valid" id="inputSuccess" placeholder="Enter ...">
                  </div>
                  <div class="form-group">
                    <label class="col-form-label" for="inputWarning"><i class="far fa-bell"></i> Input with
                      warning</label>
                    <input type="text" class="form-control is-warning" id="inputWarning" placeholder="Enter ...">
                  </div>
                  <div class="form-group">
                    <label class="col-form-label" for="inputError"><i class="far fa-times-circle"></i> Input with
                      error</label>
                    <input type="text" class="form-control is-invalid" id="inputError" placeholder="Enter ...">
                  </div>

                  <div class="row">
                    <div class="col-sm-6"> -->
                      <!-- checkbox -->
                      <!-- <div class="form-group">
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox">
                          <label class="form-check-label">Checkbox</label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" checked>
                          <label class="form-check-label">Checkbox checked</label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" disabled>
                          <label class="form-check-label">Checkbox disabled</label>
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-6"> -->
                      <!-- radio -->
                      <!-- <div class="form-group">
                        <div class="form-check">
                          <input class="form-check-input" type="radio" name="radio1">
                          <label class="form-check-label">Radio</label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="radio" name="radio1" checked>
                          <label class="form-check-label">Radio checked</label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="radio" disabled>
                          <label class="form-check-label">Radio disabled</label>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-sm-6"> -->
                      <!-- select -->
                      <!-- <div class="form-group">
                        <label>Select</label>
                        <select class="form-control">
                          <option>option 1</option>
                          <option>option 2</option>
                          <option>option 3</option>
                          <option>option 4</option>
                          <option>option 5</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>Select Disabled</label>
                        <select class="form-control" disabled>
                          <option>option 1</option>
                          <option>option 2</option>
                          <option>option 3</option>
                          <option>option 4</option>
                          <option>option 5</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-sm-6"> -->
                      <!-- Select multiple-->
                      <!-- <div class="form-group">
                        <label>Select Multiple</label>
                        <select multiple class="form-control">
                          <option>option 1</option>
                          <option>option 2</option>
                          <option>option 3</option>
                          <option>option 4</option>
                          <option>option 5</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>Select Multiple Disabled</label>
                        <select multiple class="form-control" disabled>
                          <option>option 1</option>
                          <option>option 2</option>
                          <option>option 3</option>
                          <option>option 4</option>
                          <option>option 5</option>
                        </select> -->
                      </div>
                    </div>
                    
                  </div>

                
                </form>
              </div>
              <!-- /.card-body -->
            </div>
</div>
</section>