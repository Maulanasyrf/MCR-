<nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
               <li class="nav-item">
            <a href="index.php?page=dashboard" class="nav-link">
              <i class="nav-icon fas fa-th-large"></i>
              <p>
               Dashboard
                <span class="right badge badge-danger"></span>
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-chart-bar"></i>
              <p>
                Report
                <i class="right fas fa-chevron-circle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
            <li class="nav-item">
                <a href="index.php?page=ritasi" class="nav-link ">
                  <i class="nav-icon fas fa-chart-pie"></i>
                  <p>PCA OB</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=ritasi" class="nav-link ">
                  <i class="nav-icon fas fa-chart-pie"></i>
                  <p>Ritase</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=status" class="nav-link">
                  <i class="nav-icon fas fa-chart-pie"></i>
                  <p>Status</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=dailyrace" class="nav-link" >
                  <i class="nav-icon fas fa-chart-pie"></i>
                  <p>Daily Race</p>
                </a>
              </li>
              
              <li class="nav-item">
                <a href="index.php?page=dailyeng" class="nav-link" >
                  <i class="nav-icon fas fa-chart-pie"></i>
                  <p>Daily Eng</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=monthly" class="nav-link">
                  <i class="nav-icon fas fa-chart-pie"></i>
                  <p>Monthly</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=dailyrace" class="nav-link" >
                  <i class="nav-icon fas fa-chart-pie"></i>
                  <p>Years</p>
                </a>
              </li>
              </ul>
              <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-database "></i>
              <p>
                Master Data
                <i class="right fas fa-chevron-circle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="index.php?page=master-customer" class="nav-link ">
                  <i class="nav-icon fas fa-cube"></i>
                  <p>Customer</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=master-operator" class="nav-link">
                  <i class="nav-icon fas fa-user"></i>
                  <p>Operator</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=master-user" class="nav-link">
                  <i class="nav-icon fas fa-users"></i>
                  <p>User</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=master-site" class="nav-link">
                  <i class="nav-icon fas fa-circle"></i>
                  <p>Site</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=master-equipment" class="nav-link">
                  <i class="nav-icon fas fa-circle "></i>
                  <p>Equipment</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=master-sitelocation" class="nav-link">
                  <i class="nav-icon fas fa-circle "></i>
                  <p>Location</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=master-sitefactor" class="nav-link">
                  <i class="nav-icon fas fa-circle"></i>
                  <p>Factor</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=master-versionplan" class="nav-link">
                  <i class="nav-icon fas fa-circle"></i>
                  <p>Version Plan</p>
                </a>
              </li>
            </ul>
          </li>
           <li class="nav-item">
            <a href="logout.php" class="nav-link text-red">
              <i class="nav-icon fas fa-power-off"></i>
              <p>
                Logout
                
              </p>
            </a>
          </li>
          
        </ul>
      </nav>