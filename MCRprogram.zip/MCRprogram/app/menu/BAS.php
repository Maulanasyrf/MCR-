<nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="index.php?page=dashboard" class="nav-link" >
              <i class="nav-icon fas fa-th-large"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          
          <li class="nav-item ">
            <a  class="nav-link ">
              <i class="nav-icon fas fa-desktop"></i>
              <p>
                Input Data
                <i class="right fas fa-chevron-circle-left"></i>
              </p>  
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="index.php?page=plan_actual" class="nav-link" >
                  <i class="nav-icon fas fa-edit"></i>
                  <p>Plan and Actual</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=rain" class="nav-link" >
                  <i class="nav-icon  fas fa-edit"></i>
                  <p>Rain and Slippery</p>
                </a>
              </li>
          </li>
      
          <li class="nav-item">
            <a href="index.php?page=data-ritasi" class="nav-link" >
              <i class="nav-icon fas fa-edit" ></i>
              <p>
                Ritase
              </p>
            </a>
          </li>  
          <li class="nav-item">
            <a href="index.php?page=status" class="nav-link" >
              <i class="nav-icon fas fa-edit"></i>
              <p>
                Status
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="index.php?page=breakdown" class="nav-link" >
              <i class="nav-icon fas fa-edit"></i>
              <p>
                Breakdown
              </p>
            </a>
          </li>
        </ul>
          <li class="nav-item menu  ">
            <a  class="nav-link ">
              <i class="nav-icon fas fa-chart-bar"></i>
              <p>
                Data Report
                <i class="right fas fa-chevron-circle-left"></i>
              </p>  
            </a>
            <ul class="nav nav-treeview">
              
              <li class="nav-item">
                <a href="index.php?page=pca-production" class="nav-link" >
                  <i class="nav-icon fas fa-chart-pie"></i>
                  <p>PCA</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=perfomance-detail" class="nav-link" >
                  <i class="nav-icon fas fa-chart-pie"></i>
                  <p>Performance Detail</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=hourly-production" class="nav-link" >
                  <i class="nav-icon fas fa-chart-pie"></i>
                  <p>Hourly Production</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=performance-summary" class="nav-link"  >
                  <i class="nav-icon fas fa-chart-pie"></i>
                  <p>Performance Summary</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=production-perfomance" class="nav-link">
                  <i class="nav-icon fas fa-chart-pie"></i>
                  <p>Production Performance</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=fuel-consumption" class="nav-link" >
                  <i class="nav-icon fas fa-chart-pie"></i>
                  <p>Fuel Consumption</p>
                </a>
              </li>
              
            </ul>
          <li class="nav-item menu">
            <a  class="nav-link">
              <i class="nav-icon fas fa-database "></i>
              <p>
                Master Data
                <i class="right fas fa-chevron-circle-left"></i>
              </p>  
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="index.php?page=master-operator" class="nav-link" >
                  <i class="nav-icon fas fa-user"></i>
                  <p>Operator</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=master-equipment" class="nav-link"  >
                  <i class="nav-icon fas fa-truck"></i>
                  <p>Equipment</p>
                </a>
              </li>
             
              <li class="nav-item">
                <a href="index.php?page=master-sitelocation" class="nav-link" >
                  <i class="nav-icon fas fa-map-pin"></i>
                  <p>Location</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=master-sitefactor" class="nav-link" >
                  <i class="nav-icon fas fa-industry"></i>
                  <p>Factor</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?page=master-versionplan" class="nav-link" >
                  <i class="nav-icon fas  fa-cog"></i>
                  <p>Versionplan</p>
                </a>
              </li>
            </ul>
          </li>   
          <li class="nav-item">
            <a href="logout.php" class="nav-link text-red">
              <i class="nav-icon fas fa-power-off"></i>
              <p>
                Logout
                
              </p>
            </a>
          </li>
        </ul>
         <!-- Tab panes -->
    
      </div>
      </nav>
     