<?php
require '../vendor/autoload.php';
require '../config/koneksi.php';
if(isset ($_POST['submit'])){
  $err        = "";
  $ekstensi   = "";
  $success    = "";

  $file_name = $_FILES['filexls']['name'];
  $file_data = $_FILES['filexls']['tmp_name'];

  if(empty($file_name)){
    $err .= "<li> Silahkan Masukan File.</li>";

  }else{
    $ekstensi = pathinfo($file_name)['extension'];

  }
  $ekstensi_allowed = array ("xls","xlsx");
  if (!in_array($ekstensi,$ekstensi_allowed)){
    $err .= "<li> Silahkan Masukan File tipe xls, atau xlsx. <b>$file_name</b> punya tipe <b>$ekstensi</b></li>";
  }
  if(empty($err)){
    $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile($file_data);
    $spreadsheet = $reader->load($file_data);
    $sheetData = $spreadsheet->getActiveSheet()->toArray();

    $jumlahData = 0;
    for($i=1;$i<count($sheetData);$i++){
      $nik = $sheetData[$i]['0'];
      $nama = $sheetData[$i]['1'];
      $versatility = $sheetData[$i]['2'];
      $site = $sheetData[$i]['3'];

      $sql1 = "insert into operator (nik, nama, versatility, site) values ('$nik','$nama','$versatility','$site')";
      
      mysqli_query  ($koneksi,$sql1);
      $jumlahData++;
      

    }

    if($jumlahData > 0 ){
      $success = "Data Berhasil di Import";
    
      }
      
  } 
  
  if($err){
    ?>
    <div class ="alert alert-danger">
      <ul><?php echo $err ?></ul>
  </div>
  <?php

  }
  if ($success){
    ?>
    <div class="alert alert-primary">
      <?php echo $success ?>
      
  </div>
  
  <?php
  
  }
}

?>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Master Operator</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
              <div class = "form-group">
              <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-lg">
                  Tambah Operator
              </button>
</div>
             <div class ="form-group">
              
       
              <div class="btn-group w-20">
             <form action="" method="POST" enctype="multipart/form-data" >
              <input class="btn btn-primary col fileinput-button "type="file" name="filexls">
</div>
              <input class="btn btn-success" type="submit" name="submit" value="Upload Excel">


</form>
</div>
</div>


               
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>NIK</th>
                    <th>Nama</th>
                    <th>Versatility</th>
                    <th>Sitecode</th>
                    <!-- <th>Action</th> -->
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                    $no = 0;
                    $query = mysqli_query($koneksi, "SELECT * FROM operator");
                    while ($operator= mysqli_fetch_array($query)){
                      $no++
                    ?>
                  <tr>
                  
                    <td width='5%'><?php echo $operator['no'];?></td>
                    <td><?php echo $operator['nik'];?></td>
                    <td><?php echo $operator['nama'];?></td>
                    <td><?php echo $operator['versatility'];?></td>
                    <td><?php echo $operator['site'];?></td>
                    <!-- <td><a onclick="hapus_op(<?php echo $operator['no'];?>)" class="btn btn-sm btn-danger">Hapus</a>
                        <a href="index.php?page=edit-data&& no=<?php echo $operator['no'];?>" class="btn btn-sm btn-success">Edit</a>
                  </td> -->
                  </tr>
                  <?php }?>

                  </tbody>
                  
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
      </section>
      <div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Master Operator</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <form method="get" action="add/tambah_op.php">
            <div class="modal-body">
            <div class="form-row">
            
            <div class="col">
                <input type="text" class="form-control" placeholder="NIK" name ="nik" required>
              </div>
              <div class="col">
                <input type="text" class="form-control" placeholder="Nama" name ="nama" required>
              </div>
              <div class="col">
                <input type="text" class="form-control" placeholder="Versatility" name ="versatility" required>
              </div>
              <div class="col">
                <input type="text" class="form-control" placeholder="Sitecode" name ="sitecode">
              </div>
            </div>
          
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Save</button>
            </div>
          </div>
          </form>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <script>
        function hapus_op(data_op){
          // alert('ok');
          // window.location=("delete/hapus_op.php?code="+data_customer);
          Swal.fire({
              title: 'Apakah anda yakin ingin menghapus data?',
              // showDenyButton: false,
              showCancelButton: true,
              confirmButtonText: 'Hapus Data',
              confirmButtonColor:'red'
              // denyButtonText: `Don't save`,
            }).then((result) => {
              /* Read more about isConfirmed, isDenied below */
              if (result.isConfirmed) {
                window.location=("delete/hapus_op.php?nik="+data_op);
              } 
            })
        }
      </script>
              
             