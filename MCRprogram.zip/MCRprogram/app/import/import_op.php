
             <form action="" method="POST" enctype="multipart/form-data" >
              <input class="btn btn-info"type="file" name="filexls">
              <input class="btn btn-success" type="submit" name="submit" value="Upload Excel">
            </form>