<!DOCTYPE html>
<html lang="en">
<?php 
session_start();
if(!$_SESSION['nama']){
  header('Location:../index.php?session=expired');
}
include('header.php');?>
<?php include('../config/koneksi.php');?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Preloader -->
  <?php include ('preloader.php');?>
  <!-- Navbar -->
<?php include ('navbar.php');?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <?php include('logo.php');?>
    <!-- Sidebar -->
    <?php include('sidebar.php');?>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
  
    <!-- /.content-header -->

    <!-- Main content -->
    <?php 
    if(isset($_GET['page'])){
    if($_GET['page']=='dashboard'){
      include ('dashboard.php');
    }
    else if($_GET['page']=='master-customer'){
      include('db_customer.php');
    }
    else if($_GET['page']=='master-operator'){
      include('db_operator.php');
    } 
    else if($_GET['page']=='master-truckfactor'){
      include('tb_truckfactor.php');
    } 
    else if($_GET['page']=='master-equipment'){
      include('db_equipment.php');
    } 
    else if($_GET['page']=='master-site'){
      include('db_site.php');
    }   
    else if($_GET['page']=='master-sitefactor'){
      include('db_sitefactor.php');
    }   
    else if($_GET['page']=='master-sitelocation'){
      include('db_sitelocation.php');
    }      
    else if($_GET['page']=='data-ritasi'){
      include('dataritasi.php');
    } 
    else if($_GET['page']=='hourly'){
      include('hourly.php');
    } 
    else if($_GET['page']=='rain'){
      include('rain.php');
    } 
    else if($_GET['page']=='pca-production'){
      include('pca.php');
    } 
    else if($_GET['page']=='plan_actual'){
      include('plan.php');
    } 
     else if($_GET['page']=='produksi'){
      include('produksi.php');
    }  
    else if($_GET['page']=='status'){
      include('status.php');
    } 
    else if($_GET['page']=='upload-ritase'){
      include('upload_ritase.php');
    }   
    else if($_GET['page']=='tabel-equipcategori'){
      include('tb_equipcategori.php');
    }  
    else if($_GET['page']=='tabel-equipmodel'){
      include('tb_model.php');
    }    
    else if($_GET['page']=='tabel-equiptype'){
      include('tb_tipe.php');
    }                      
    else if($_GET['page']=='tabel-dedicated'){
      include('tb_dedicated.php');
    }                      
    else if($_GET['page']=='tabel-locationtype'){
      include('tb_location.php');
    }                      
    else if($_GET['page']=='tabel-material'){
      include('tb_material.php');
    }                      
    else if($_GET['page']=='tabel-submaterial'){
      include('tb_submaterial.php');
    }  
    else if($_GET['page']=='tabel-timecategori'){
      include('tb_time.php');
    }  
    else if($_GET['page']=='tabel-produksiproblem'){
      include('tb_problem.php');
    }                      
    else if($_GET['page']=='tabel-planningtype'){
      include('tb_planning.php');
    }                      
    else if($_GET['page']=='tabel-planningactivity'){
      include('tb_activity.php');
    }                                                                                
    else if($_GET['page']=='edit-data'){
      include('edit/edit_data.php');
    }
    else if($_GET['page']=='edit-equip'){
      include('edit/edit_equip.php');
    
    }
    else if($_GET['page']=='hourly-production'){
      include('hourly.php');
    
    }
    
    
    else{
      include('not_found.php');
    }
  } 
  else{
    include('dashboard.php');
  }
      ?>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
    <?php include ('footer.php');?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


</body>
</html>
